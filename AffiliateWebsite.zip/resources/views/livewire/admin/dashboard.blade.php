<div>
    <livewire:admin.url-generate />
    <livewire:admin.get-amazon-product-details />
</div>