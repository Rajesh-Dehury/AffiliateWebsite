<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="//cdn.ckeditor.com/4.22.0/standard/ckeditor.js"></script>
</head>

<body class="bg-gray-300 h-screen font-sans" x-cloak x-data="{menu:false,darkMode: $persist(true)}" :class="{'dark': darkMode === true }">
    <div class="relative md:grid md:grid-cols-11">
        <?php if (isset($component)) { $__componentOriginale9c3bce8cff1d83625028cfee0507b05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9c3bce8cff1d83625028cfee0507b05 = $attributes; } ?>
<?php $component = App\View\Components\AdminSideNav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-side-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminSideNav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9c3bce8cff1d83625028cfee0507b05)): ?>
<?php $attributes = $__attributesOriginale9c3bce8cff1d83625028cfee0507b05; ?>
<?php unset($__attributesOriginale9c3bce8cff1d83625028cfee0507b05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9c3bce8cff1d83625028cfee0507b05)): ?>
<?php $component = $__componentOriginale9c3bce8cff1d83625028cfee0507b05; ?>
<?php unset($__componentOriginale9c3bce8cff1d83625028cfee0507b05); ?>
<?php endif; ?>
        <div class="md:col-span-9 w-full z-0 min-h-screen">
            <?php if (isset($component)) { $__componentOriginaldce7f6279c83542827cd8b205c22d8d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldce7f6279c83542827cd8b205c22d8d4 = $attributes; } ?>
<?php $component = App\View\Components\AdminTopNav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-top-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminTopNav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldce7f6279c83542827cd8b205c22d8d4)): ?>
<?php $attributes = $__attributesOriginaldce7f6279c83542827cd8b205c22d8d4; ?>
<?php unset($__attributesOriginaldce7f6279c83542827cd8b205c22d8d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldce7f6279c83542827cd8b205c22d8d4)): ?>
<?php $component = $__componentOriginaldce7f6279c83542827cd8b205c22d8d4; ?>
<?php unset($__componentOriginaldce7f6279c83542827cd8b205c22d8d4); ?>
<?php endif; ?>
            <?php echo e($slot); ?>

        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\rajes\Desktop\Projects\AffiliateWebsite\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>