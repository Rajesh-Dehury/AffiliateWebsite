<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'title'=>'Pages',
'url'=>'#',
'active'=>false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'title'=>'Pages',
'url'=>'#',
'active'=>false,
]); ?>
<?php foreach (array_filter(([
'title'=>'Pages',
'url'=>'#',
'active'=>false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <a wire:navigate href="<?php echo e($url); ?>" class="flex items-center px-4 py-2 <?php echo e($active?'bg-gray-700 text-white':'text-gray-700 dark:text-white'); ?> rounded-md mb-2 hover:bg-gray-700 hover:text-white">
        <?php echo e($icon); ?>


        <span class="mx-4 font-medium"><?php echo e($title); ?></span>
    </a>
</div><?php /**PATH C:\Users\rajes\Desktop\Projects\AffiliateWebsite\resources\views/components/nav-item.blade.php ENDPATH**/ ?>