<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</head>

<body class="bg-gray-300 h-screen font-sans">
    <?php if (isset($component)) { $__componentOriginal36683b03a9f071d9abbd7c21d36810e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36683b03a9f071d9abbd7c21d36810e9 = $attributes; } ?>
<?php $component = App\View\Components\HomeTopNav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-top-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeTopNav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36683b03a9f071d9abbd7c21d36810e9)): ?>
<?php $attributes = $__attributesOriginal36683b03a9f071d9abbd7c21d36810e9; ?>
<?php unset($__attributesOriginal36683b03a9f071d9abbd7c21d36810e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36683b03a9f071d9abbd7c21d36810e9)): ?>
<?php $component = $__componentOriginal36683b03a9f071d9abbd7c21d36810e9; ?>
<?php unset($__componentOriginal36683b03a9f071d9abbd7c21d36810e9); ?>
<?php endif; ?>
    <div class="min-h-screen">
        <?php echo e($slot); ?>

    </div>
    <div class="fixed bottom-4 right-4 flex flex-col space-y-3">
        <!-- WhatsApp Icon -->
        <a href="https://wa.me/YOUR_PHONE_NUMBER" target="_blank" class="bg-green-500 p-2.5 rounded-full shadow-lg hover:bg-green-600 hover:drop-shadow-lg hover:shadow-green-300 transition duration-300">
            <img src="<?php echo e(asset('whatsapp-svgrepo-com.svg')); ?>" alt="" class="h-10 w-10 transition duration-300">
        </a>

        <!-- Telegram Icon -->
        <a href="https://t.me/YOUR_TELEGRAM_USERNAME" target="_blank" class="bg-blue-500 p-2.5 rounded-full shadow-lg hover:bg-blue-600 hover:drop-shadow-lg hover:shadow-blue-300 transition duration-300">
            <img src="<?php echo e(asset('telegram-svgrepo-com.svg')); ?>" alt="" class="h-10 w-10">
        </a>
    </div>

    <?php if (isset($component)) { $__componentOriginal8a74de07fa946b754e34beb008b64ff5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a74de07fa946b754e34beb008b64ff5 = $attributes; } ?>
<?php $component = App\View\Components\HomeFooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a74de07fa946b754e34beb008b64ff5)): ?>
<?php $attributes = $__attributesOriginal8a74de07fa946b754e34beb008b64ff5; ?>
<?php unset($__attributesOriginal8a74de07fa946b754e34beb008b64ff5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a74de07fa946b754e34beb008b64ff5)): ?>
<?php $component = $__componentOriginal8a74de07fa946b754e34beb008b64ff5; ?>
<?php unset($__componentOriginal8a74de07fa946b754e34beb008b64ff5); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\Users\rajes\Desktop\Projects\AffiliateWebsite\resources\views/components/home-layout.blade.php ENDPATH**/ ?>