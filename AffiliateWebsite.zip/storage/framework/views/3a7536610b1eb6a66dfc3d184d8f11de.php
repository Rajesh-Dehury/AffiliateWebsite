<div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.url-generate', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1984244566-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.get-amazon-product-details', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1984244566-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div><?php /**PATH C:\Users\rajes\Desktop\Projects\AffiliateWebsite\resources\views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>